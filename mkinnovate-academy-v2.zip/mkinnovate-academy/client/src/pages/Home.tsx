import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight, BookOpen, Users, TrendingUp, Award, Zap, CheckCircle, Star } from "lucide-react";
import { Link } from "wouter";
import { getLoginUrl } from "@/const";
import Navigation from "@/components/Navigation";

export default function Home() {
  const { user, isAuthenticated } = useAuth();

  const courses = [
    {
      icon: "🤖",
      title: "Crie Sites com Inteligência Artificial",
      slug: "ia",
      price: "R$ 149",
      students: 234,
      rating: 4.9,
      description: "Crie sites profissionais em horas usando IA, mesmo sem saber programar.",
      features: ["Acesso vitalício", "Certificado profissional", "Suporte de mentores"],
    },
    {
      icon: "💻",
      title: "Criação de Sites do Zero",
      slug: "web",
      price: "R$ 299",
      students: 567,
      rating: 4.8,
      description: "Aprenda HTML, CSS e JavaScript e comece a vender sites.",
      features: ["8 semanas de conteúdo", "Projetos reais", "Comunidade ativa"],
    },
    {
      icon: "📱",
      title: "React Native - Apps Mobile",
      slug: "mobile",
      price: "R$ 599",
      students: 123,
      rating: 4.9,
      description: "Crie aplicativos para Android e iOS com uma única linguagem.",
      features: ["10 semanas", "Apps profissionais", "Suporte prioritário"],
    },
    {
      icon: "🎬",
      title: "Edição de Vídeo Profissional",
      slug: "edicao",
      price: "R$ 149,90",
      students: 456,
      rating: 4.7,
      description: "Do básico ao nível cinematográfico. Aprenda com profissionais.",
      features: ["6 semanas", "Templates inclusos", "Comunidade de criadores"],
    },
  ];

  const testimonials = [
    {
      name: "João Silva",
      role: "Desenvolvedor Freelancer",
      image: "👨‍💼",
      text: "Depois do curso de IA, comecei a criar sites em 50% menos tempo. Minha receita triplicou!",
      rating: 5,
    },
    {
      name: "Maria Santos",
      role: "Criadora de Conteúdo",
      image: "👩‍💼",
      text: "O curso de edição de vídeo transformou meu canal. Agora consigo 10k views por vídeo.",
      rating: 5,
    },
    {
      name: "Pedro Costa",
      role: "Empreendedor Digital",
      image: "👨‍🎓",
      text: "Aprendi React Native e lancei meu primeiro app. Já tem 5k downloads!",
      rating: 5,
    },
  ];

  const benefits = [
    {
      icon: <Award className="w-6 h-6" />,
      title: "Certificados Profissionais",
      description: "Certificados reconhecidos no mercado para impulsionar sua carreira",
    },
    {
      icon: <Users className="w-6 h-6" />,
      title: "Comunidade Ativa",
      description: "Conecte-se com outros alunos e profissionais da área",
    },
    {
      icon: <TrendingUp className="w-6 h-6" />,
      title: "Conteúdo Atualizado",
      description: "Aulas atualizadas com as últimas tendências do mercado",
    },
    {
      icon: <Star className="w-6 h-6" />,
      title: "Suporte Dedicado",
      description: "Mentores disponíveis 24/7 para tirar suas dúvidas",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="pt-32 pb-20 bg-gradient-to-br from-primary/5 via-background to-secondary/5">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-block mb-4 px-4 py-2 bg-primary/10 rounded-full">
                <span className="text-sm font-semibold text-primary">🚀 Transforme sua carreira</span>
              </div>
              <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
                Domine as habilidades digitais do futuro
              </h1>
              <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
                Aprenda desenvolvimento web, apps mobile, inteligência artificial e edição profissional com especialistas da indústria. Comece sua jornada hoje.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="#cursos">
                  <Button size="lg" className="w-full sm:w-auto">
                    Explorar Cursos
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
                {!isAuthenticated && (
                  <a href={getLoginUrl()}>
                    <Button size="lg" variant="outline" className="w-full sm:w-auto">
                      Entrar na Plataforma
                    </Button>
                  </a>
                )}
              </div>
            </div>
            <div className="hidden md:block">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-primary to-secondary rounded-2xl blur-3xl opacity-20" />
                <div className="relative bg-gradient-to-br from-primary/10 to-secondary/10 rounded-2xl p-8 border border-primary/20">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-4xl">🤖</div>
                    <div className="text-4xl">💻</div>
                    <div className="text-4xl">📱</div>
                    <div className="text-4xl">🎬</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Stats */}
          <div className="grid md:grid-cols-4 gap-6 mt-16">
            <div className="text-center">
              <div className="text-4xl font-bold text-primary mb-2">1.380+</div>
              <p className="text-muted-foreground">Alunos Satisfeitos</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-secondary mb-2">50+</div>
              <p className="text-muted-foreground">Cursos Disponíveis</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-blue-500 mb-2">4.8★</div>
              <p className="text-muted-foreground">Avaliação Média</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-purple-500 mb-2">24/7</div>
              <p className="text-muted-foreground">Suporte Dedicado</p>
            </div>
          </div>
        </div>
      </section>

      {/* Benefícios */}
      <section id="beneficios" className="py-20 bg-background">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Por que escolher a MKinnovate Academy?</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Oferecemos uma experiência de aprendizado completa com recursos que garantem seu sucesso
            </p>
          </div>
          <div className="grid md:grid-cols-4 gap-6">
            {benefits.map((benefit, i) => (
              <Card key={i} className="p-6 hover:shadow-lg transition-shadow">
                <div className="text-primary mb-4">{benefit.icon}</div>
                <h3 className="text-lg font-semibold mb-2">{benefit.title}</h3>
                <p className="text-muted-foreground">{benefit.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Cursos */}
      <section id="cursos" className="py-20 bg-muted/30">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Nossos Cursos</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Escolha entre 4 formações estruturadas para impulsionar sua carreira
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {courses.map((course, i) => (
              <Link key={i} href={`/curso/${course.slug}`}>
                <Card className="h-full overflow-hidden hover:shadow-xl transition-all hover:-translate-y-1 cursor-pointer">
                  <div className="bg-gradient-to-br from-primary/10 to-secondary/10 p-6 h-32 flex items-center justify-center">
                    <span className="text-6xl">{course.icon}</span>
                  </div>
                  <div className="p-6">
                    <h3 className="font-bold text-lg mb-2 line-clamp-2">{course.title}</h3>
                    <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{course.description}</p>
                    
                    <div className="flex items-center gap-2 mb-4 text-sm">
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      <span className="font-semibold">{course.rating}</span>
                      <span className="text-muted-foreground">({course.students} alunos)</span>
                    </div>

                    <div className="space-y-2 mb-6 text-sm">
                      {course.features.map((feature, j) => (
                        <div key={j} className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-secondary" />
                          <span>{feature}</span>
                        </div>
                      ))}
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-2xl font-bold text-primary">{course.price}</span>
                      <Button size="sm" variant="outline">
                        Ver Curso
                        <ArrowRight className="w-4 h-4 ml-1" />
                      </Button>
                    </div>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Depoimentos */}
      <section id="depoimentos" className="py-20 bg-background">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">O que nossos alunos dizem</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Histórias reais de sucesso de alunos que transformaram suas carreiras
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, i) => (
              <Card key={i} className="p-6">
                <div className="flex items-center gap-4 mb-4">
                  <div className="text-4xl">{testimonial.image}</div>
                  <div>
                    <p className="font-semibold">{testimonial.name}</p>
                    <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                  </div>
                </div>
                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, j) => (
                    <Star key={j} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-muted-foreground italic">"{testimonial.text}"</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-20 bg-gradient-to-r from-primary/10 to-secondary/10">
        <div className="container text-center">
          <h2 className="text-4xl font-bold mb-6">Pronto para começar?</h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Junte-se a mais de 1.380 alunos que já transformaram suas carreiras
          </p>
          <Link href="#cursos">
            <Button size="lg" className="px-8">
              Explorar Cursos Agora
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-muted/50 border-t border-border py-12">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-bold mb-4">MKinnovate Academy</h3>
              <p className="text-sm text-muted-foreground">
                Transformando habilidades digitais em renda real
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Cursos</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#cursos" className="hover:text-primary transition-colors">Desenvolvimento Web</a></li>
                <li><a href="#cursos" className="hover:text-primary transition-colors">Apps Mobile</a></li>
                <li><a href="#cursos" className="hover:text-primary transition-colors">Inteligência Artificial</a></li>
                <li><a href="#cursos" className="hover:text-primary transition-colors">Edição de Vídeo</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Empresa</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">Sobre</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Blog</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Contato</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">Termos</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Privacidade</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Cookies</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2026 MKinnovate Academy. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
