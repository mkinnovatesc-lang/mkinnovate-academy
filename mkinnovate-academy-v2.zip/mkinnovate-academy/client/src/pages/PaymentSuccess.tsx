import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { CheckCircle, BookOpen, Download } from "lucide-react";
import { Link } from "wouter";
import { useEffect, useState } from "react";

export default function PaymentSuccess() {
  const [orderDetails, setOrderDetails] = useState<any>(null);

  useEffect(() => {
    // Get payment details from URL params
    const params = new URLSearchParams(window.location.search);
    const paymentId = params.get("payment_id");
    const preferenceId = params.get("preference_id");
    const externalReference = params.get("external_reference");

    setOrderDetails({
      paymentId,
      preferenceId,
      externalReference,
      timestamp: new Date().toLocaleString("pt-BR"),
    });
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-secondary/5 flex items-center justify-center p-4">
      <Card className="max-w-md w-full p-8 text-center">
        {/* Success Icon */}
        <div className="mb-6 flex justify-center">
          <div className="relative">
            <div className="absolute inset-0 bg-secondary/20 rounded-full blur-xl" />
            <CheckCircle className="w-20 h-20 text-secondary relative" />
          </div>
        </div>

        {/* Title */}
        <h1 className="text-3xl font-bold mb-2">Pagamento Realizado!</h1>
        <p className="text-muted-foreground mb-6">
          Seu pagamento foi processado com sucesso. Você já tem acesso ao curso!
        </p>

        {/* Order Details */}
        {orderDetails && (
          <div className="bg-muted/50 rounded-lg p-4 mb-6 text-left text-sm">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">ID do Pagamento:</span>
                <span className="font-mono text-xs break-all">
                  {orderDetails.paymentId || "Processando..."}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Data/Hora:</span>
                <span>{orderDetails.timestamp}</span>
              </div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="space-y-3">
          <Link href="/minha-area" className="block">
            <Button size="lg" className="w-full">
              <BookOpen className="w-4 h-4 mr-2" />
              Acessar Meu Curso
            </Button>
          </Link>
          <Button size="lg" variant="outline" className="w-full">
            <Download className="w-4 h-4 mr-2" />
            Baixar Recibo
          </Button>
        </div>

        {/* Additional Info */}
        <div className="mt-8 pt-6 border-t border-border text-sm text-muted-foreground">
          <p className="mb-3">
            Um email de confirmação foi enviado para seu endereço de email registrado.
          </p>
          <p>
            Caso tenha dúvidas, entre em contato com nosso suporte através do email ou chat.
          </p>
        </div>

        {/* Back to Home */}
        <Link href="/" className="block mt-6">
          <Button variant="ghost" className="w-full">
            Voltar para Home
          </Button>
        </Link>
      </Card>
    </div>
  );
}
