import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight, BookOpen } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";

const coursesData = [
  {
    id: 1,
    icon: "🤖",
    title: "Crie Sites com Inteligência Artificial",
    slug: "ia",
    description: "Crie sites profissionais em horas usando IA, mesmo sem saber programar.",
    price: 149,
    category: "ia",
    level: "iniciante",
    students: 234,
    rating: 4.9,
  },
  {
    id: 2,
    icon: "💻",
    title: "Criação de Sites do Zero",
    slug: "web",
    description: "Aprenda HTML, CSS e JavaScript e comece a vender sites.",
    price: 299,
    category: "web",
    level: "intermediario",
    students: 567,
    rating: 4.8,
  },
  {
    id: 3,
    icon: "📱",
    title: "React Native - Apps Mobile",
    slug: "mobile",
    description: "Crie aplicativos para Android e iOS com uma única linguagem.",
    price: 599,
    category: "mobile",
    level: "avancado",
    students: 123,
    rating: 4.9,
  },
  {
    id: 4,
    icon: "🎬",
    title: "Edição de Vídeo Profissional",
    slug: "edicao",
    description: "Do básico ao nível cinematográfico. Aprenda com profissionais.",
    price: 149.9,
    category: "edicao",
    level: "iniciante",
    students: 456,
    rating: 4.7,
  },
  {
    id: 5,
    icon: "🤖",
    title: "IA Avançada para Desenvolvedores",
    slug: "ia-avancada",
    description: "Integre modelos de IA em suas aplicações. Nível avançado.",
    price: 799,
    category: "ia",
    level: "avancado",
    students: 89,
    rating: 4.9,
  },
  {
    id: 6,
    icon: "💻",
    title: "Next.js Masterclass",
    slug: "nextjs",
    description: "Domine Next.js e crie aplicações web modernas e escaláveis.",
    price: 399,
    category: "web",
    level: "intermediario",
    students: 234,
    rating: 4.8,
  },
];

export default function Courses() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedLevel, setSelectedLevel] = useState<string | null>(null);

  const filteredCourses = coursesData.filter((course) => {
    if (selectedCategory && course.category !== selectedCategory) return false;
    if (selectedLevel && course.level !== selectedLevel) return false;
    return true;
  });

  const categories = [
    { value: "ia", label: "IA & Automação" },
    { value: "web", label: "Web Development" },
    { value: "mobile", label: "Mobile Apps" },
    { value: "edicao", label: "Edição de Vídeo" },
  ];

  const levels = [
    { value: "iniciante", label: "Iniciante" },
    { value: "intermediario", label: "Intermediário" },
    { value: "avancado", label: "Avançado" },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="border-b border-border sticky top-0 z-50 bg-background/95 backdrop-blur">
        <div className="container flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2 hover:opacity-80">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-bold text-lg">MKinnovate Academy</span>
          </Link>
          <Link href="/">
            <Button variant="ghost">Voltar</Button>
          </Link>
        </div>
      </nav>

      <div className="container py-12">
        <div className="mb-12">
          <h1 className="text-4xl font-bold mb-4">Explore Nossos Cursos</h1>
          <p className="text-muted-foreground text-lg">
            Escolha entre mais de 50 cursos em diferentes áreas da tecnologia e negócios digitais.
          </p>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Sidebar Filters */}
          <div className="lg:col-span-1">
            <div className="bg-card p-6 rounded-lg border border-border sticky top-24">
              <h3 className="font-semibold mb-4">Filtrar por Categoria</h3>
              <div className="space-y-2 mb-6">
                <button
                  onClick={() => setSelectedCategory(null)}
                  className={`block w-full text-left px-3 py-2 rounded transition-colors ${
                    selectedCategory === null
                      ? "bg-primary text-primary-foreground"
                      : "hover:bg-muted"
                  }`}
                >
                  Todas as Categorias
                </button>
                {categories.map((cat) => (
                  <button
                    key={cat.value}
                    onClick={() => setSelectedCategory(cat.value)}
                    className={`block w-full text-left px-3 py-2 rounded transition-colors ${
                      selectedCategory === cat.value
                        ? "bg-primary text-primary-foreground"
                        : "hover:bg-muted"
                    }`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>

              <h3 className="font-semibold mb-4">Filtrar por Nível</h3>
              <div className="space-y-2">
                <button
                  onClick={() => setSelectedLevel(null)}
                  className={`block w-full text-left px-3 py-2 rounded transition-colors ${
                    selectedLevel === null
                      ? "bg-primary text-primary-foreground"
                      : "hover:bg-muted"
                  }`}
                >
                  Todos os Níveis
                </button>
                {levels.map((level) => (
                  <button
                    key={level.value}
                    onClick={() => setSelectedLevel(level.value)}
                    className={`block w-full text-left px-3 py-2 rounded transition-colors ${
                      selectedLevel === level.value
                        ? "bg-primary text-primary-foreground"
                        : "hover:bg-muted"
                    }`}
                  >
                    {level.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Courses Grid */}
          <div className="lg:col-span-3">
            <div className="mb-6 flex items-center justify-between">
              <p className="text-muted-foreground">
                Mostrando {filteredCourses.length} de {coursesData.length} cursos
              </p>
              {(selectedCategory || selectedLevel) && (
                <button
                  onClick={() => {
                    setSelectedCategory(null);
                    setSelectedLevel(null);
                  }}
                  className="text-sm text-primary hover:underline"
                >
                  Limpar filtros
                </button>
              )}
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              {filteredCourses.map((course) => (
                <Link key={course.id} href={`/curso/${course.slug}`}>
                  <Card className="hover:shadow-lg transition-all hover:border-primary cursor-pointer h-full flex flex-col overflow-hidden group">
                    <div className="bg-gradient-to-br from-primary/10 to-secondary/10 p-6 flex items-center justify-between">
                      <div className="text-5xl">{course.icon}</div>
                      <span className="text-xs font-semibold px-3 py-1 bg-primary/20 text-primary rounded-full">
                        {course.level === "iniciante" ? "Iniciante" : course.level === "intermediario" ? "Intermediário" : "Avançado"}
                      </span>
                    </div>
                    <div className="p-6 flex flex-col flex-grow">
                      <h3 className="text-lg font-semibold mb-2 group-hover:text-primary transition-colors">
                        {course.title}
                      </h3>
                      <p className="text-sm text-muted-foreground mb-4 flex-grow">
                        {course.description}
                      </p>
                      <div className="flex items-center justify-between pt-4 border-t border-border">
                        <div>
                          <div className="text-2xl font-bold text-primary">
                            R$ {course.price.toFixed(2)}
                          </div>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1">
                            <span>⭐ {course.rating}</span>
                            <span>•</span>
                            <span>{course.students} alunos</span>
                          </div>
                        </div>
                        <ArrowRight className="w-5 h-5 text-primary group-hover:translate-x-1 transition-transform" />
                      </div>
                    </div>
                  </Card>
                </Link>
              ))}
            </div>

            {filteredCourses.length === 0 && (
              <div className="text-center py-12">
                <p className="text-muted-foreground text-lg">
                  Nenhum curso encontrado com os filtros selecionados.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
