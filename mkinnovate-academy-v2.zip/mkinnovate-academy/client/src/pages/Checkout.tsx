import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, Loader2, Lock, CheckCircle } from "lucide-react";
import { Link, useParams } from "wouter";
import Navigation from "@/components/Navigation";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";

export default function Checkout() {
  const { slug } = useParams<{ slug: string }>();
  const { isAuthenticated } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const courseQuery = trpc.courses.getById.useQuery(
    { id: Number(slug) || 0 },
    { enabled: !!slug }
  );

  const createPaymentMutation = trpc.payment.createPreference.useMutation();

  const handleCheckout = async () => {
    if (!isAuthenticated) {
      window.location.href = getLoginUrl("/checkout/" + slug);
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const result = await createPaymentMutation.mutateAsync({
        courseId: Number(slug) || 0,
        courseTitle: courseQuery.data?.title || "Curso",
        price: Number(courseQuery.data?.price) || 0,
      });

      if (result.init_point) {
        window.location.href = result.init_point;
      } else {
        setError("Erro ao processar pagamento. Tente novamente.");
      }
    } catch (err) {
      setError("Erro ao processar pagamento. Tente novamente.");
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  if (courseQuery.isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="pt-32 pb-20 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  if (!courseQuery.data) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="pt-32 pb-20 container">
          <Link href="/cursos">
            <Button variant="ghost" className="mb-8">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar para Cursos
            </Button>
          </Link>
          <Card className="p-8 text-center">
            <p className="text-lg text-muted-foreground">Curso não encontrado</p>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <section className="pt-32 pb-20">
        <div className="container">
          <Link href="/cursos">
            <Button variant="ghost" className="mb-8">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar para Cursos
            </Button>
          </Link>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Resumo do Curso */}
            <div className="md:col-span-2">
              <Card className="p-8 mb-8">
                <h1 className="text-3xl font-bold mb-4">{courseQuery.data.title}</h1>
                <p className="text-muted-foreground mb-6">{courseQuery.data.description}</p>

                <div className="bg-muted/50 rounded-lg p-6 mb-6">
                  <h3 className="font-semibold mb-4">O que você vai aprender:</h3>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-secondary mt-0.5 flex-shrink-0" />
                      <span>Conteúdo prático e atualizado com as últimas tendências</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-secondary mt-0.5 flex-shrink-0" />
                      <span>Acesso vitalício ao curso e todas as atualizações futuras</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-secondary mt-0.5 flex-shrink-0" />
                      <span>Certificado profissional reconhecido no mercado</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-secondary mt-0.5 flex-shrink-0" />
                      <span>Suporte dedicado de mentores experientes</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-secondary mt-0.5 flex-shrink-0" />
                      <span>Comunidade ativa de alunos para trocar experiências</span>
                    </li>
                  </ul>
                </div>

                <div className="border-t border-border pt-6">
                  <h3 className="font-semibold mb-4">Detalhes do Curso:</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Categoria</p>
                      <p className="font-semibold capitalize">{courseQuery.data.category}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Nível</p>
                      <p className="font-semibold capitalize">{courseQuery.data.level}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Duração</p>
                      <p className="font-semibold">{courseQuery.data.duration}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Instrutor</p>
                      <p className="font-semibold">{courseQuery.data.instructor}</p>
                    </div>
                  </div>
                </div>
              </Card>
            </div>

            {/* Card de Pagamento */}
            <div>
              <Card className="p-6 sticky top-32">
                <div className="mb-6">
                  <p className="text-sm text-muted-foreground mb-2">Preço do Curso</p>
                  <div className="flex items-baseline gap-2">
                    <span className="text-4xl font-bold text-primary">
                      R$ {(Number(courseQuery.data.price) / 100).toFixed(2)}
                    </span>
                  </div>
                </div>

                {error && (
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
                    <p className="text-sm text-red-800">{error}</p>
                  </div>
                )}

                <Button
                  size="lg"
                  className="w-full mb-4"
                  onClick={handleCheckout}
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Processando...
                    </>
                  ) : (
                    <>
                      <Lock className="w-4 h-4 mr-2" />
                      Comprar Agora
                    </>
                  )}
                </Button>

                <p className="text-xs text-muted-foreground text-center mb-6">
                  Pagamento seguro com Mercado Pago
                </p>

                <div className="border-t border-border pt-6 space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span className="font-semibold">R$ {(Number(courseQuery.data.price) / 100).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Taxas</span>
                    <span className="font-semibold">Grátis</span>
                  </div>
                  <div className="border-t border-border pt-3 flex justify-between">
                    <span className="font-semibold">Total</span>
                    <span className="font-bold text-lg text-primary">
                      R$ {(Number(courseQuery.data.price) / 100).toFixed(2)}
                    </span>
                  </div>
                </div>

                <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                  <p className="text-xs text-blue-800">
                    ✓ Acesso imediato após o pagamento
                    <br />✓ Garantia de 7 dias de reembolso
                    <br />✓ Certificado digital incluído
                  </p>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
