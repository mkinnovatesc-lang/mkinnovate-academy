import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { BookOpen, Users, DollarSign, TrendingUp, BarChart3, PieChart } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";
import { LineChart, Line, PieChart as PieChartComponent, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

export default function Admin() {
  const { user, isAuthenticated } = useAuth();
  const [activeTab, setActiveTab] = useState("dashboard");

  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Acesso Restrito</h1>
          <p className="text-muted-foreground mb-6">Você não tem permissão para acessar esta página.</p>
          <Link href="/">
            <Button>Voltar para Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  const salesData = [
    { month: "Jan", sales: 4000, revenue: 2400 },
    { month: "Fev", sales: 3000, revenue: 1398 },
    { month: "Mar", sales: 2000, revenue: 9800 },
    { month: "Abr", sales: 2780, revenue: 3908 },
    { month: "Mai", sales: 1890, revenue: 4800 },
    { month: "Jun", sales: 2390, revenue: 3800 },
  ];

  const courseStats = [
    { name: "IA", value: 234, fill: "#3b82f6" },
    { name: "Web", value: 567, fill: "#10b981" },
    { name: "Mobile", value: 123, fill: "#f59e0b" },
    { name: "Edição", value: 456, fill: "#8b5cf6" },
  ];

  const recentSales = [
    {
      id: 1,
      studentName: "João Silva",
      course: "Crie Sites com IA",
      amount: 149,
      date: "2026-02-27",
      status: "approved",
    },
    {
      id: 2,
      studentName: "Maria Santos",
      course: "React Native",
      amount: 599,
      date: "2026-02-27",
      status: "approved",
    },
    {
      id: 3,
      studentName: "Pedro Costa",
      course: "Criação de Sites",
      amount: 299,
      date: "2026-02-26",
      status: "approved",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <nav className="border-b border-border sticky top-0 z-50 bg-background/95 backdrop-blur">
        <div className="container flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2 hover:opacity-80">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-bold text-lg">MKinnovate Academy</span>
          </Link>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">Admin: {user?.name}</span>
            <Link href="/">
              <Button variant="ghost" size="sm">
                Sair
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      <div className="container py-12">
        <div className="flex gap-4 mb-8 border-b border-border">
          <button
            onClick={() => setActiveTab("dashboard")}
            className={`px-4 py-2 font-medium transition-colors ${
              activeTab === "dashboard"
                ? "text-primary border-b-2 border-primary"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <BarChart3 className="w-4 h-4 inline mr-2" />
            Dashboard
          </button>
          <button
            onClick={() => setActiveTab("sales")}
            className={`px-4 py-2 font-medium transition-colors ${
              activeTab === "sales"
                ? "text-primary border-b-2 border-primary"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <DollarSign className="w-4 h-4 inline mr-2" />
            Vendas
          </button>
          <button
            onClick={() => setActiveTab("students")}
            className={`px-4 py-2 font-medium transition-colors ${
              activeTab === "students"
                ? "text-primary border-b-2 border-primary"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <Users className="w-4 h-4 inline mr-2" />
            Alunos
          </button>
        </div>

        {activeTab === "dashboard" && (
          <div className="space-y-8">
            <div className="grid md:grid-cols-4 gap-4">
              <Card className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm mb-1">Receita Total</p>
                    <p className="text-3xl font-bold">R$ 47.234,50</p>
                  </div>
                  <DollarSign className="w-10 h-10 text-primary opacity-20" />
                </div>
              </Card>
              <Card className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm mb-1">Total de Vendas</p>
                    <p className="text-3xl font-bold">1.380</p>
                  </div>
                  <TrendingUp className="w-10 h-10 text-secondary opacity-20" />
                </div>
              </Card>
              <Card className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm mb-1">Alunos Ativos</p>
                    <p className="text-3xl font-bold">1.380</p>
                  </div>
                  <Users className="w-10 h-10 text-blue-500 opacity-20" />
                </div>
              </Card>
              <Card className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm mb-1">Cursos Ativos</p>
                    <p className="text-3xl font-bold">50</p>
                  </div>
                  <BookOpen className="w-10 h-10 text-purple-500 opacity-20" />
                </div>
              </Card>
            </div>

            <div className="grid lg:grid-cols-2 gap-8">
              <Card className="p-6">
                <h3 className="text-lg font-semibold mb-4">Vendas e Receita</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={salesData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="sales" stroke="#3b82f6" name="Vendas" />
                    <Line type="monotone" dataKey="revenue" stroke="#10b981" name="Receita (R$)" />
                  </LineChart>
                </ResponsiveContainer>
              </Card>

              <Card className="p-6">
                <h3 className="text-lg font-semibold mb-4">Distribuição por Curso</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChartComponent>
                    <Pie
                      data={courseStats}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => `${name}: ${value}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {courseStats.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.fill} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChartComponent>
                </ResponsiveContainer>
              </Card>
            </div>
          </div>
        )}

        {activeTab === "sales" && (
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Vendas Recentes</h3>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 font-semibold">Aluno</th>
                    <th className="text-left py-3 px-4 font-semibold">Curso</th>
                    <th className="text-right py-3 px-4 font-semibold">Valor</th>
                    <th className="text-left py-3 px-4 font-semibold">Data</th>
                    <th className="text-left py-3 px-4 font-semibold">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {recentSales.map((sale) => (
                    <tr key={sale.id} className="border-b border-border hover:bg-muted/50 transition-colors">
                      <td className="py-3 px-4">{sale.studentName}</td>
                      <td className="py-3 px-4">{sale.course}</td>
                      <td className="text-right py-3 px-4 font-semibold">R$ {sale.amount.toFixed(2)}</td>
                      <td className="py-3 px-4">{sale.date}</td>
                      <td className="py-3 px-4">
                        <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-xs font-semibold">
                          Aprovado
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        )}

        {activeTab === "students" && (
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Alunos Cadastrados</h3>
            <div className="space-y-4">
              {[
                { name: "João Silva", email: "joao@example.com", courses: 1, joinDate: "2026-02-27" },
                { name: "Maria Santos", email: "maria@example.com", courses: 2, joinDate: "2026-02-27" },
                { name: "Pedro Costa", email: "pedro@example.com", courses: 1, joinDate: "2026-02-26" },
              ].map((student, i) => (
                <div key={i} className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors">
                  <div>
                    <p className="font-semibold">{student.name}</p>
                    <p className="text-sm text-muted-foreground">{student.email}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">{student.courses} curso(s)</p>
                    <p className="text-sm text-muted-foreground">{student.joinDate}</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
