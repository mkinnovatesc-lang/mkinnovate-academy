import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { BookOpen, Play, Download, Award, Clock, CheckCircle } from "lucide-react";
import { Link } from "wouter";
import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";

export default function StudentArea() {
  const { user, isAuthenticated } = useAuth();
  const [purchases, setPurchases] = useState<any[]>([]);
  const { data: purchasesData, isLoading } = trpc.payment.getUserPurchases.useQuery();

  useEffect(() => {
    if (purchasesData) {
      setPurchases(purchasesData);
    }
  }, [purchasesData]);

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Acesso Restrito</h1>
          <p className="text-muted-foreground mb-6">Você precisa estar autenticado para acessar esta página.</p>
          <Link href="/">
            <Button>Voltar para Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  const coursesData: Record<number, any> = {
    1: {
      icon: "🤖",
      title: "Crie Sites com Inteligência Artificial",
      slug: "ia",
      modules: 4,
      totalLessons: 23,
    },
    2: {
      icon: "💻",
      title: "Criação de Sites do Zero",
      slug: "web",
      modules: 4,
      totalLessons: 45,
    },
    3: {
      icon: "📱",
      title: "React Native - Apps Mobile",
      slug: "mobile",
      modules: 4,
      totalLessons: 36,
    },
    4: {
      icon: "🎬",
      title: "Edição de Vídeo Profissional",
      slug: "edicao",
      modules: 4,
      totalLessons: 27,
    },
  };

  const approvedPurchases = purchases.filter((p) => p.status === "approved");

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="border-b border-border sticky top-0 z-50 bg-background/95 backdrop-blur">
        <div className="container flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2 hover:opacity-80">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-bold text-lg">MKinnovate Academy</span>
          </Link>
          <div className="flex items-center gap-4">
            <Link href="/cursos" className="text-sm font-medium hover:text-primary transition-colors">
              Explorar Cursos
            </Link>
            {user?.role === "admin" && (
              <Link href="/admin" className="text-sm font-medium hover:text-primary transition-colors">
                Admin
              </Link>
            )}
          </div>
        </div>
      </nav>

      <div className="container py-12">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-4xl font-bold mb-2">Bem-vindo, {user?.name}!</h1>
          <p className="text-muted-foreground text-lg">
            Aqui você pode acessar todos os seus cursos adquiridos e acompanhar seu progresso.
          </p>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-4 mb-12">
          <Card className="p-6">
            <div className="text-3xl font-bold text-primary mb-2">{approvedPurchases.length}</div>
            <p className="text-muted-foreground">Cursos Adquiridos</p>
          </Card>
          <Card className="p-6">
            <div className="text-3xl font-bold text-secondary mb-2">0</div>
            <p className="text-muted-foreground">Cursos Concluídos</p>
          </Card>
          <Card className="p-6">
            <div className="text-3xl font-bold text-blue-500 mb-2">0%</div>
            <p className="text-muted-foreground">Progresso Médio</p>
          </Card>
          <Card className="p-6">
            <div className="text-3xl font-bold text-purple-500 mb-2">0</div>
            <p className="text-muted-foreground">Certificados</p>
          </Card>
        </div>

        {/* Courses */}
        <div>
          <h2 className="text-2xl font-bold mb-6">Meus Cursos</h2>

          {isLoading ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground">Carregando seus cursos...</p>
            </div>
          ) : approvedPurchases.length === 0 ? (
            <Card className="p-12 text-center">
              <BookOpen className="w-16 h-16 text-muted-foreground mx-auto mb-4 opacity-50" />
              <h3 className="text-xl font-semibold mb-2">Nenhum curso adquirido ainda</h3>
              <p className="text-muted-foreground mb-6">
                Explore nossos cursos e comece sua jornada de aprendizado hoje mesmo.
              </p>
              <Link href="/cursos">
                <Button>Explorar Cursos</Button>
              </Link>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {approvedPurchases.map((purchase) => {
                const course = coursesData[purchase.courseId];
                if (!course) return null;

                return (
                  <Card key={purchase.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="bg-gradient-to-br from-primary/10 to-secondary/10 p-6 flex items-center justify-between">
                      <div className="text-4xl">{course.icon}</div>
                      <span className="text-xs font-semibold px-3 py-1 bg-secondary/20 text-secondary rounded-full">
                        Em Progresso
                      </span>
                    </div>
                    <div className="p-6">
                      <h3 className="text-lg font-semibold mb-2">{course.title}</h3>

                      {/* Progress Bar */}
                      <div className="mb-4">
                        <div className="flex items-center justify-between text-sm mb-2">
                          <span className="text-muted-foreground">Progresso</span>
                          <span className="font-semibold">0%</span>
                        </div>
                        <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                          <div className="h-full w-0 bg-secondary rounded-full transition-all" />
                        </div>
                      </div>

                      {/* Course Info */}
                      <div className="space-y-2 mb-6 text-sm text-muted-foreground">
                        <div className="flex items-center gap-2">
                          <BookOpen className="w-4 h-4" />
                          <span>{course.modules} módulos</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Play className="w-4 h-4" />
                          <span>{course.totalLessons} aulas</span>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="space-y-2">
                        <Link href={`/curso/${course.slug}`} className="w-full">
                          <Button size="sm" className="w-full">
                            <Play className="w-4 h-4 mr-2" />
                            Continuar Aprendendo
                          </Button>
                        </Link>
                        <Button size="sm" variant="outline" className="w-full">
                          <Download className="w-4 h-4 mr-2" />
                          Baixar Certificado
                        </Button>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          )}
        </div>

        {/* Recommended Courses */}
        {approvedPurchases.length > 0 && (
          <div className="mt-16">
            <h2 className="text-2xl font-bold mb-6">Cursos Recomendados</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                {
                  icon: "🤖",
                  title: "IA Avançada para Desenvolvedores",
                  price: "R$ 799",
                },
                {
                  icon: "💻",
                  title: "Next.js Masterclass",
                  price: "R$ 399",
                },
                {
                  icon: "📱",
                  title: "Flutter - Apps Mobile",
                  price: "R$ 599",
                },
                {
                  icon: "🎬",
                  title: "Motion Graphics Profissional",
                  price: "R$ 299",
                },
              ].map((course, i) => (
                <Card key={i} className="p-6 hover:shadow-lg transition-shadow cursor-pointer">
                  <div className="text-4xl mb-3">{course.icon}</div>
                  <h3 className="font-semibold mb-2">{course.title}</h3>
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-primary">{course.price}</span>
                    <Button size="sm" variant="outline">
                      Saiba Mais
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
