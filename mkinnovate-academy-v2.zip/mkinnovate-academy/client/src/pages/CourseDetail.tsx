import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, BookOpen, Clock, Users, Award, CheckCircle, Play } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { toast } from "sonner";

const coursesData: Record<string, any> = {
  ia: {
    id: 1,
    icon: "🤖",
    title: "Crie Sites com Inteligência Artificial",
    slug: "ia",
    price: 149,
    category: "ia",
    level: "iniciante",
    students: 234,
    rating: 4.9,
    instructor: "Carlos Silva",
    duration: "4 semanas",
    description: "Crie sites profissionais em horas usando IA, mesmo sem saber programar.",
    longDescription: `Aprenda a criar sites profissionais e funcionais em poucas horas usando as ferramentas mais avançadas de inteligência artificial disponíveis no mercado. Neste curso, você não precisa saber programar - a IA faz o trabalho pesado enquanto você aprende a direcionar e otimizar os resultados.

Você vai aprender desde o básico até criar sites completos com funcionalidades avançadas, tudo usando IA. Ideal para empreendedores, freelancers e agências que querem oferecer serviços de criação de sites com mais velocidade e qualidade.`,
    modules: [
      {
        title: "Módulo 1: Introdução à IA para Web",
        lessons: 5,
        duration: "2h 30min",
      },
      {
        title: "Módulo 2: Ferramentas de IA para Design",
        lessons: 6,
        duration: "3h 15min",
      },
      {
        title: "Módulo 3: Criando seu Primeiro Site",
        lessons: 8,
        duration: "4h 45min",
      },
      {
        title: "Módulo 4: Otimização e Deploy",
        lessons: 4,
        duration: "2h 20min",
      },
    ],
    benefits: [
      "Crie sites em horas, não em dias",
      "Sem necessidade de conhecimento em programação",
      "Aprenda as melhores ferramentas de IA",
      "Certificado profissional ao final",
      "Acesso vitalício ao conteúdo",
      "Suporte direto com mentores",
    ],
    requirements: [
      "Computador com acesso à internet",
      "Vontade de aprender",
      "Nenhum conhecimento técnico prévio necessário",
    ],
  },
  web: {
    id: 2,
    icon: "💻",
    title: "Criação de Sites do Zero",
    slug: "web",
    price: 299,
    category: "web",
    level: "intermediario",
    students: 567,
    rating: 4.8,
    instructor: "Ana Costa",
    duration: "8 semanas",
    description: "Aprenda HTML, CSS e JavaScript e comece a vender sites.",
    longDescription: `Domine os fundamentos do desenvolvimento web e crie sites profissionais do zero. Este curso é perfeito para quem quer aprender a programar e começar a ganhar dinheiro criando sites para clientes.

Você vai aprender HTML5, CSS3, JavaScript moderno e as melhores práticas de desenvolvimento. Ao final do curso, você terá criado vários projetos reais que podem ser adicionados ao seu portfólio.`,
    modules: [
      {
        title: "Módulo 1: HTML5 Fundamentals",
        lessons: 10,
        duration: "5h",
      },
      {
        title: "Módulo 2: CSS3 Avançado",
        lessons: 12,
        duration: "6h",
      },
      {
        title: "Módulo 3: JavaScript Essencial",
        lessons: 15,
        duration: "8h",
      },
      {
        title: "Módulo 4: Projetos Reais",
        lessons: 8,
        duration: "6h",
      },
    ],
    benefits: [
      "Aprenda as tecnologias mais demandadas",
      "Crie projetos reais para seu portfólio",
      "Comece a vender sites",
      "Certificado reconhecido no mercado",
      "Comunidade ativa de alunos",
      "Atualizações constantes do conteúdo",
    ],
    requirements: [
      "Computador com editor de código",
      "Conhecimento básico de internet",
      "Dedicação e prática regular",
    ],
  },
  mobile: {
    id: 3,
    icon: "📱",
    title: "React Native - Apps Mobile",
    slug: "mobile",
    price: 599,
    category: "mobile",
    level: "avancado",
    students: 123,
    rating: 4.9,
    instructor: "Pedro Oliveira",
    duration: "10 semanas",
    description: "Crie aplicativos para Android e iOS com uma única linguagem.",
    longDescription: `Aprenda React Native e crie aplicativos profissionais para iOS e Android com uma única base de código. Este curso é ideal para desenvolvedores que querem expandir suas habilidades para o desenvolvimento mobile.

Você vai aprender desde os conceitos básicos até criar aplicativos complexos com integração de APIs, autenticação e muito mais.`,
    modules: [
      {
        title: "Módulo 1: React Native Basics",
        lessons: 8,
        duration: "4h",
      },
      {
        title: "Módulo 2: Componentes e Navegação",
        lessons: 10,
        duration: "5h",
      },
      {
        title: "Módulo 3: Integração com APIs",
        lessons: 12,
        duration: "6h",
      },
      {
        title: "Módulo 4: Deploy e Publicação",
        lessons: 6,
        duration: "3h",
      },
    ],
    benefits: [
      "Desenvolva para iOS e Android simultaneamente",
      "Aprenda com um especialista da indústria",
      "Crie apps profissionais",
      "Certificado de conclusão",
      "Acesso a comunidade exclusiva",
      "Suporte técnico prioritário",
    ],
    requirements: [
      "Conhecimento de JavaScript/React",
      "Computador com capacidade de desenvolvimento",
      "Node.js instalado",
    ],
  },
  edicao: {
    id: 4,
    icon: "🎬",
    title: "Edição de Vídeo Profissional",
    slug: "edicao",
    price: 149.9,
    category: "edicao",
    level: "iniciante",
    students: 456,
    rating: 4.7,
    instructor: "Mariana Silva",
    duration: "6 semanas",
    description: "Do básico ao nível cinematográfico. Aprenda com profissionais.",
    longDescription: `Domine as técnicas de edição de vídeo profissional e crie conteúdo de qualidade cinematográfica. Este curso cobre desde os conceitos básicos até técnicas avançadas de color grading, efeitos especiais e pós-produção.

Perfeito para criadores de conteúdo, YouTubers, cineastas e profissionais de marketing que querem elevar a qualidade de seus vídeos.`,
    modules: [
      {
        title: "Módulo 1: Introdução à Edição",
        lessons: 6,
        duration: "3h",
      },
      {
        title: "Módulo 2: Ferramentas Profissionais",
        lessons: 8,
        duration: "4h",
      },
      {
        title: "Módulo 3: Efeitos e Transições",
        lessons: 10,
        duration: "5h",
      },
      {
        title: "Módulo 4: Color Grading e Finalização",
        lessons: 7,
        duration: "4h",
      },
    ],
    benefits: [
      "Aprenda com profissionais da indústria",
      "Técnicas usadas em produções profissionais",
      "Crie vídeos de qualidade cinematográfica",
      "Certificado profissional",
      "Acesso a templates e recursos",
      "Comunidade de criadores",
    ],
    requirements: [
      "Computador com bom processador",
      "Software de edição (fornecemos recomendações)",
      "Interesse em criação de conteúdo",
    ],
  },
};

interface CourseDetailProps {
  params: { slug: string };
}

export default function CourseDetail({ params }: CourseDetailProps) {
  const { slug } = params;
  const course = coursesData[slug];
  const { user, isAuthenticated } = useAuth();
  const [isLoading, setIsLoading] = useState(false);

  if (!course) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Curso não encontrado</h1>
          <Link href="/cursos">
            <Button>Voltar para Cursos</Button>
          </Link>
        </div>
      </div>
    );
  }

  const handleBuyCourse = async () => {
    if (!isAuthenticated) {
      window.location.href = getLoginUrl(`/curso/${slug}`);
      return;
    }

    setIsLoading(true);
    try {
      // Criar preference diretamente com Mercado Pago
      const response = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          courseId: course.id,
          courseTitle: course.title,
          price: course.price,
          userId: user?.id,
        }),
      });

      if (!response.ok) {
        const error = await response.text();
        console.error("Erro na resposta:", error);
        throw new Error("Erro ao criar preferência de pagamento");
      }

      const data = await response.json();
      console.log("Resposta do servidor:", data);
      
      if (data.init_point) {
        window.location.href = data.init_point;
      } else if (data.url) {
        window.location.href = data.url;
      } else {
        throw new Error("URL de pagamento não recebida");
      }
    } catch (error) {
      console.error("Erro:", error);
      toast.error("Erro ao processar pagamento. Tente novamente.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="border-b border-border sticky top-0 z-50 bg-background/95 backdrop-blur">
        <div className="container flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2 hover:opacity-80">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-bold text-lg">MKinnovate Academy</span>
          </Link>
          <Link href="/cursos" className="flex items-center gap-2 text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-4 h-4" />
            Voltar
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary/10 to-secondary/10 py-12">
        <div className="container">
          <div className="grid md:grid-cols-3 gap-8 items-start">
            <div className="md:col-span-2">
              <div className="text-6xl mb-4">{course.icon}</div>
              <h1 className="text-4xl font-bold mb-4">{course.title}</h1>
              <p className="text-lg text-muted-foreground mb-6">{course.longDescription}</p>
              <div className="flex flex-wrap gap-4 mb-8">
                <div className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-primary" />
                  <span>{course.students} alunos</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-yellow-400">⭐ {course.rating}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-primary" />
                  <span>{course.duration}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-primary" />
                  <span>Certificado</span>
                </div>
              </div>
            </div>
            <Card className="p-6 h-fit sticky top-24">
              <div className="text-4xl font-bold text-primary mb-4">R$ {course.price.toFixed(2)}</div>
              <Button
                size="lg"
                className="w-full mb-4"
                onClick={handleBuyCourse}
                disabled={isLoading}
              >
                {isLoading ? "Processando..." : "Comprar Agora"}
              </Button>
              <Button size="lg" variant="outline" className="w-full mb-6">
                <Play className="w-4 h-4 mr-2" />
                Assistir Preview
              </Button>
              <div className="space-y-3 text-sm">
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-secondary mt-0.5 flex-shrink-0" />
                  <span>Acesso vitalício</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-secondary mt-0.5 flex-shrink-0" />
                  <span>Certificado profissional</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-secondary mt-0.5 flex-shrink-0" />
                  <span>Suporte de mentores</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle className="w-4 h-4 text-secondary mt-0.5 flex-shrink-0" />
                  <span>Comunidade exclusiva</span>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Course Content */}
      <section className="container py-12">
        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2">
            {/* Instructor */}
            <Card className="p-6 mb-8">
              <h2 className="text-2xl font-bold mb-4">Instrutor</h2>
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center text-2xl">
                  👨‍🏫
                </div>
                <div>
                  <h3 className="font-semibold text-lg">{course.instructor}</h3>
                  <p className="text-muted-foreground">Especialista em {course.category}</p>
                </div>
              </div>
            </Card>

            {/* Modules */}
            <Card className="p-6 mb-8">
              <h2 className="text-2xl font-bold mb-6">Conteúdo do Curso</h2>
              <div className="space-y-4">
                {course.modules.map((module: any, i: number) => (
                  <div key={i} className="border border-border rounded-lg p-4 hover:bg-muted/50 transition-colors cursor-pointer">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-semibold mb-2">{module.title}</h3>
                        <div className="flex gap-4 text-sm text-muted-foreground">
                          <span>{module.lessons} aulas</span>
                          <span>•</span>
                          <span>{module.duration}</span>
                        </div>
                      </div>
                      <Play className="w-5 h-5 text-primary flex-shrink-0" />
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            {/* Benefits */}
            <Card className="p-6">
              <h2 className="text-2xl font-bold mb-6">O que você vai aprender</h2>
              <div className="grid md:grid-cols-2 gap-4">
                {course.benefits.map((benefit: string, i: number) => (
                  <div key={i} className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-secondary flex-shrink-0 mt-0.5" />
                    <span className="text-sm">{benefit}</span>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Requirements */}
            <Card className="p-6">
              <h3 className="font-bold mb-4">Pré-requisitos</h3>
              <ul className="space-y-2">
                {course.requirements.map((req: string, i: number) => (
                  <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    {req}
                  </li>
                ))}
              </ul>
            </Card>

            {/* Stats */}
            <Card className="p-6">
              <h3 className="font-bold mb-4">Informações</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Alunos</span>
                  <span className="font-semibold">{course.students}+</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Avaliação</span>
                  <span className="font-semibold">{course.rating}★</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Duração</span>
                  <span className="font-semibold">{course.duration}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Nível</span>
                  <span className="font-semibold capitalize">{course.level}</span>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Related Courses */}
      <section className="bg-muted/50 py-12">
        <div className="container">
          <h2 className="text-3xl font-bold mb-8">Outros Cursos que Podem Interessar</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {Object.values(coursesData)
              .filter((c: any) => c.slug !== slug)
              .slice(0, 3)
              .map((c: any) => (
                <Link key={c.slug} href={`/cursos/${c.slug}`}>
                  <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer h-full">
                    <div className="text-4xl mb-3">{c.icon}</div>
                    <h3 className="font-bold mb-2">{c.title}</h3>
                    <p className="text-sm text-muted-foreground mb-4">{c.description}</p>
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-primary">R$ {c.price.toFixed(2)}</span>
                      <span className="text-yellow-400">⭐ {c.rating}</span>
                    </div>
                  </Card>
                </Link>
              ))}
          </div>
        </div>
      </section>
    </div>
  );
}
