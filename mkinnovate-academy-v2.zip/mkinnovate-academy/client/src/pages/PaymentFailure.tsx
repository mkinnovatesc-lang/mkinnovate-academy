import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { AlertCircle, BookOpen, ArrowLeft } from "lucide-react";
import { Link } from "wouter";

export default function PaymentFailure() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-red-50 flex items-center justify-center p-4">
      <Card className="max-w-md w-full p-8 text-center">
        {/* Error Icon */}
        <div className="mb-6 flex justify-center">
          <div className="relative">
            <div className="absolute inset-0 bg-red-100 rounded-full blur-xl" />
            <AlertCircle className="w-20 h-20 text-red-600 relative" />
          </div>
        </div>

        {/* Title */}
        <h1 className="text-3xl font-bold mb-2">Pagamento Não Aprovado</h1>
        <p className="text-muted-foreground mb-6">
          Desculpe, não conseguimos processar seu pagamento. Tente novamente ou use outro método de pagamento.
        </p>

        {/* Error Details */}
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6 text-left text-sm">
          <p className="text-red-800 font-semibold mb-2">Possíveis motivos:</p>
          <ul className="text-red-700 space-y-1 list-disc list-inside">
            <li>Dados do cartão incorretos</li>
            <li>Saldo insuficiente</li>
            <li>Cartão expirado</li>
            <li>Transação bloqueada pelo banco</li>
          </ul>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          <Link href="/cursos" className="block">
            <Button size="lg" className="w-full">
              <BookOpen className="w-4 h-4 mr-2" />
              Tentar Novamente
            </Button>
          </Link>
          <Link href="/" className="block">
            <Button size="lg" variant="outline" className="w-full">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar para Home
            </Button>
          </Link>
        </div>

        {/* Support Info */}
        <div className="mt-8 pt-6 border-t border-border text-sm text-muted-foreground">
          <p className="mb-3">
            Ainda tendo problemas? Entre em contato com nosso suporte.
          </p>
          <p className="text-primary font-semibold">
            suporte@mkinnovate.com.br
          </p>
        </div>
      </Card>
    </div>
  );
}
