# Guia de Deployment no Vercel

## Pré-requisitos

1. Conta no GitHub
2. Conta no Vercel
3. Banco de dados MySQL (TiDB ou similar)
4. Credenciais do Mercado Pago

## Passo 1: Preparar o Repositório GitHub

```bash
# Clonar o repositório
git clone https://github.com/seu-usuario/mkinnovate-academy.git
cd mkinnovate-academy

# Instalar dependências
pnpm install

# Fazer commit inicial
git add .
git commit -m "Initial commit: MKinnovate Academy platform"
git push origin main
```

## Passo 2: Configurar no Vercel

1. Acesse https://vercel.com
2. Clique em "Add New" → "Project"
3. Selecione seu repositório `mkinnovate-academy`
4. Configure as variáveis de ambiente:

### Variáveis de Ambiente Necessárias

```
DATABASE_URL=mysql://user:password@host:port/database
JWT_SECRET=sua-chave-secreta-jwt
VITE_APP_ID=seu-app-id-manus
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://manus.im/login
OWNER_NAME=Seu Nome
OWNER_OPEN_ID=seu-open-id
MP_ACCESS_TOKEN=APP_USR-seu-access-token
MP_PUBLIC_KEY=APP_USR-sua-public-key
BUILT_IN_FORGE_API_URL=https://api.manus.im
BUILT_IN_FORGE_API_KEY=sua-forge-api-key
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im
VITE_FRONTEND_FORGE_API_KEY=sua-frontend-forge-api-key
VITE_ANALYTICS_ENDPOINT=seu-endpoint-analytics
VITE_ANALYTICS_WEBSITE_ID=seu-website-id
VITE_APP_TITLE=MKinnovate Academy
VITE_APP_LOGO=https://seu-logo-url.png
PUBLIC_BASE_URL=https://mkinnovate-academy.vercel.app
```

## Passo 3: Configurar Build

1. Framework Preset: **Next.js** (ou Node.js)
2. Build Command: `pnpm build`
3. Output Directory: `dist`
4. Install Command: `pnpm install`

## Passo 4: Configurar Domínio Customizado

1. Vá para Project Settings
2. Domains
3. Adicione seu domínio: `mkinnovate-academy.vercel.app`
4. Configure os DNS records conforme instruído

## Passo 5: Deploy

1. Clique em "Deploy"
2. Aguarde a build completar
3. Acesse seu site em https://mkinnovate-academy.vercel.app

## Troubleshooting

### Erro de Banco de Dados
- Verifique se a URL do DATABASE_URL está correta
- Certifique-se que o banco de dados está acessível de fora

### Erro de Mercado Pago
- Valide os tokens MP_ACCESS_TOKEN e MP_PUBLIC_KEY
- Teste no Mercado Pago Sandbox primeiro

### Erro de Build
- Execute `pnpm build` localmente para testar
- Verifique os logs no Vercel

## Próximos Passos

1. Teste o fluxo completo de compra
2. Configure o webhook do Mercado Pago
3. Monitore os logs em Vercel
4. Configure alertas de erro

## Suporte

Para dúvidas sobre o deployment, consulte:
- Documentação do Vercel: https://vercel.com/docs
- Documentação do Manus: https://manus.im/docs
