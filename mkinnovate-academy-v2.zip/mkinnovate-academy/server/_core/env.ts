export const ENV = {
  appId: process.env.VITE_APP_ID ?? "",
  cookieSecret: process.env.JWT_SECRET ?? "",
  databaseUrl: process.env.DATABASE_URL ?? "",
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
  isProduction: process.env.NODE_ENV === "production",
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? "",
  mpAccessToken: process.env.MP_ACCESS_TOKEN ?? "",
  mpPublicKey: process.env.MP_PUBLIC_KEY ?? "",
  publicBaseUrl: process.env.NEXT_PUBLIC_BASE_URL ?? process.env.VITE_APP_URL ?? "http://localhost:3000",
};
