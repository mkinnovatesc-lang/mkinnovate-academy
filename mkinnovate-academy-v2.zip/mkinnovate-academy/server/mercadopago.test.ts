import { describe, it, expect } from "vitest";
import { ENV } from "./_core/env";

describe("Mercado Pago Configuration", () => {
  it("should have MP_ACCESS_TOKEN configured", () => {
    expect(ENV.mpAccessToken).toBeTruthy();
    expect(ENV.mpAccessToken).toMatch(/^APP_USR-/);
  });

  it("should have MP_PUBLIC_KEY configured", () => {
    expect(ENV.mpPublicKey).toBeTruthy();
    expect(ENV.mpPublicKey).toMatch(/^APP_USR-/);
  });

  it("should have valid token format", () => {
    const accessToken = ENV.mpAccessToken;
    const publicKey = ENV.mpPublicKey;

    expect(accessToken).toContain("-");
    expect(publicKey).toContain("-");
    expect(accessToken.length).toBeGreaterThan(20);
    expect(publicKey.length).toBeGreaterThan(20);
  });

  it("should have public base URL configured", () => {
    expect(ENV.publicBaseUrl).toBeTruthy();
    expect(ENV.publicBaseUrl).toMatch(/^http/);
  });
});
