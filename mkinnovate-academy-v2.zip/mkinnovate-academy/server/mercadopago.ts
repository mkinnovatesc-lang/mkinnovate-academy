import { ENV } from "./_core/env";

interface MercadoPagoConfig {
  accessToken: string;
}

class MercadoPagoClient {
  private accessToken: string;
  private baseUrl = "https://api.mercadopago.com";

  constructor(config: MercadoPagoConfig) {
    this.accessToken = config.accessToken;
  }

  async createPreference(data: {
    title: string;
    price: number;
    quantity?: number;
    description?: string;
    externalReference?: string;
    notificationUrl?: string;
  }) {
    const body = {
      items: [
        {
          title: data.title,
          description: data.description,
          quantity: data.quantity || 1,
          unit_price: data.price,
        },
      ],
      back_urls: {
        success: `${ENV.publicBaseUrl}/pagamento/sucesso`,
        failure: `${ENV.publicBaseUrl}/pagamento/falha`,
        pending: `${ENV.publicBaseUrl}/pagamento/pendente`,
      },
      auto_return: "approved",
      external_reference: data.externalReference,
      notification_url: data.notificationUrl,
    };

    const response = await fetch(`${this.baseUrl}/checkout/preferences`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${this.accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      throw new Error(`Mercado Pago API error: ${response.statusText}`);
    }

    return response.json();
  }

  async getPayment(paymentId: string) {
    const response = await fetch(`${this.baseUrl}/v1/payments/${paymentId}`, {
      headers: {
        Authorization: `Bearer ${this.accessToken}`,
      },
    });

    if (!response.ok) {
      throw new Error(`Mercado Pago API error: ${response.statusText}`);
    }

    return response.json();
  }
}

let client: MercadoPagoClient | null = null;

export function getMercadoPagoClient(): MercadoPagoClient {
  if (!client) {
    if (!ENV.mpAccessToken) {
      throw new Error("Mercado Pago access token not configured");
    }
    client = new MercadoPagoClient({
      accessToken: ENV.mpAccessToken,
    });
  }
  return client;
}

export type { MercadoPagoClient };
