import { router, publicProcedure } from "../_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { getCourses, getCourseById } from "../db";

export const coursesRouter = router({
  list: publicProcedure.query(async () => {
    try {
      const courses = await getCourses();
      return courses;
    } catch (error) {
      console.error("Error fetching courses:", error);
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Erro ao buscar cursos",
      });
    }
  }),

  getById: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      try {
        const course = await getCourseById(input.id);
        if (!course) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Curso não encontrado",
          });
        }
        return course;
      } catch (error) {
        console.error("Error fetching course:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Erro ao buscar curso",
        });
      }
    }),
});
