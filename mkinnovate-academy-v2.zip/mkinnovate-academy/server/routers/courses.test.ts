import { describe, it, expect } from "vitest";

describe("Courses Router", () => {
  it("should validate course list query", () => {
    const courses = [
      {
        id: 1,
        title: "Course 1",
        price: 149,
        category: "ia",
      },
      {
        id: 2,
        title: "Course 2",
        price: 299,
        category: "web",
      },
    ];

    expect(courses).toHaveLength(2);
    expect(courses[0].id).toBe(1);
    expect(courses[0].price).toBeGreaterThan(0);
  });

  it("should validate course categories", () => {
    const validCategories = ["ia", "web", "mobile", "edicao"];
    const category = "ia";

    expect(validCategories).toContain(category);
  });

  it("should validate course levels", () => {
    const validLevels = ["iniciante", "intermediario", "avancado"];
    const level = "iniciante";

    expect(validLevels).toContain(level);
  });

  it("should validate course price", () => {
    const price = 149.99;

    expect(price).toBeGreaterThan(0);
    expect(typeof price).toBe("number");
  });
});
