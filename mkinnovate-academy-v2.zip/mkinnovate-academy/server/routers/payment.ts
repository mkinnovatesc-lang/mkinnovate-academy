import { router, publicProcedure, protectedProcedure } from "../_core/trpc";
import { z } from "zod";
import { getMercadoPagoClient } from "../mercadopago";
import { createPurchase, getCourseById, updatePurchaseStatus, getUserPurchases } from "../db";
import { TRPCError } from "@trpc/server";
import { notifyOwner } from "../_core/notification";

export const paymentRouter = router({
  createPreference: protectedProcedure
    .input(
      z.object({
        courseId: z.number(),
        courseTitle: z.string(),
        price: z.number(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        // Verify course exists
        const course = await getCourseById(input.courseId);
        if (!course) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Curso não encontrado",
          });
        }

        // Check if user already purchased this course
        const userPurchases = await getUserPurchases(ctx.user.id);
        const alreadyPurchased = userPurchases.some(
          (p) => p.courseId === input.courseId && p.status === "approved"
        );

        if (alreadyPurchased) {
          throw new TRPCError({
            code: "CONFLICT",
            message: "Você já adquiriu este curso",
          });
        }

        // Create purchase record
        const purchase = await createPurchase({
          userId: ctx.user.id,
          courseId: input.courseId,
          price: input.price as any,
          status: "pending",
        });

        // Get purchase ID from the result
        const purchaseId = (purchase as any).insertId || (purchase as any)[0]?.id;

        // Create Mercado Pago preference
        const mpClient = getMercadoPagoClient();
        const preference = await mpClient.createPreference({
          title: input.courseTitle,
          price: input.price,
          description: `Curso: ${input.courseTitle}`,
          externalReference: `purchase_${purchaseId}` as string,
          notificationUrl: `${process.env.VITE_APP_URL || "http://localhost:3000"}/api/trpc/payment.webhook`,
        });

        // Update purchase with Mercado Pago IDs
        if (preference.id) {
          // Store preference ID for later reference
          console.log("Preference created:", preference.id);
        }

        return {
          init_point: preference.init_point,
          preferenceId: preference.id,
          purchaseId,
        };
      } catch (error) {
        console.error("Payment creation error:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Erro ao criar preferência de pagamento",
        });
      }
    }),

  webhook: publicProcedure
    .input(
      z.object({
        type: z.string(),
        data: z.object({
          id: z.string(),
        }),
      })
    )
    .mutation(async ({ input }) => {
      try {
        if (input.type !== "payment") {
          return { ok: true };
        }

        const mpClient = getMercadoPagoClient();
        const paymentData = await mpClient.getPayment(input.data.id);

        if (paymentData.status === "approved") {
          const externalReference = paymentData.external_reference;
          if (externalReference && externalReference.startsWith("purchase_")) {
            const purchaseId = parseInt(externalReference.split("_")[1]);
            await updatePurchaseStatus(purchaseId, "approved");

            // Notify owner
            try {
              await notifyOwner({
                title: "Nova venda de curso!",
                content: `Um novo aluno adquiriu um curso. Verifique o painel administrativo para mais detalhes.`,
              });
            } catch (error) {
              console.error("Notification error:", error);
            }
          }
        }

        return { ok: true };
      } catch (error) {
        console.error("Webhook error:", error);
        return { ok: false };
      }
    }),

  getUserPurchases: protectedProcedure.query(async ({ ctx }) => {
    try {
      const purchases = await getUserPurchases(ctx.user.id);
      return purchases;
    } catch (error) {
      console.error("Error fetching purchases:", error);
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Erro ao buscar compras",
      });
    }
  }),
});
