import { router, protectedProcedure } from "../_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { storagePut, storageGet } from "../storage";
import { PDFDocument, rgb } from "pdf-lib";

export const certificatesRouter = router({
  generateCertificate: protectedProcedure
    .input(
      z.object({
        courseId: z.number(),
        courseName: z.string(),
        completionDate: z.date(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        // Create PDF certificate
        const pdfDoc = await PDFDocument.create();
        const page = pdfDoc.addPage([800, 600]);

        // Add background color
        page.drawRectangle({
          x: 0,
          y: 0,
          width: 800,
          height: 600,
          color: rgb(0.95, 0.97, 1), // Light blue background
        });

        // Add decorative border
        page.drawRectangle({
          x: 20,
          y: 20,
          width: 760,
          height: 560,
          borderColor: rgb(0.2, 0.4, 0.8),
          borderWidth: 3,
        });

        // Add title
        page.drawText("CERTIFICADO DE CONCLUSÃO", {
          x: 100,
          y: 480,
          size: 36,
          color: rgb(0.2, 0.4, 0.8),
          font: await pdfDoc.embedFont("Helvetica-Bold"),
        });

        // Add subtitle
        page.drawText("MKinnovate Academy", {
          x: 250,
          y: 430,
          size: 20,
          color: rgb(0.4, 0.4, 0.4),
          font: await pdfDoc.embedFont("Helvetica"),
        });

        // Add certificate text
        page.drawText("Certificamos que", {
          x: 250,
          y: 380,
          size: 14,
          color: rgb(0.3, 0.3, 0.3),
          font: await pdfDoc.embedFont("Helvetica"),
        });

        // Add student name
        page.drawText(ctx.user.name || "Aluno", {
          x: 150,
          y: 330,
          size: 24,
          color: rgb(0.2, 0.4, 0.8),
          font: await pdfDoc.embedFont("Helvetica-Bold"),
        });

        // Add course name
        page.drawText(`Completou com sucesso o curso: ${input.courseName}`, {
          x: 100,
          y: 270,
          size: 14,
          color: rgb(0.3, 0.3, 0.3),
          font: await pdfDoc.embedFont("Helvetica"),
        });

        // Add completion date
        const formattedDate = input.completionDate.toLocaleDateString("pt-BR");
        page.drawText(`Data de conclusão: ${formattedDate}`, {
          x: 250,
          y: 200,
          size: 12,
          color: rgb(0.4, 0.4, 0.4),
          font: await pdfDoc.embedFont("Helvetica"),
        });

        // Add footer
        page.drawText("Este certificado é válido como comprovante de conclusão do curso.", {
          x: 120,
          y: 80,
          size: 10,
          color: rgb(0.5, 0.5, 0.5),
          font: await pdfDoc.embedFont("Helvetica"),
        });

        // Save PDF to buffer
        const pdfBytes = await pdfDoc.save();

        // Upload to S3
        const fileKey = `certificates/${ctx.user.id}-${input.courseId}-${Date.now()}.pdf`;
        const { url } = await storagePut(
          fileKey,
          Buffer.from(pdfBytes),
          "application/pdf"
        );

        return {
          success: true,
          certificateUrl: url,
          fileKey,
        };
      } catch (error) {
        console.error("Certificate generation error:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Erro ao gerar certificado",
        });
      }
    }),

  getCertificate: protectedProcedure
    .input(z.object({ courseId: z.number() }))
    .query(async ({ input, ctx }) => {
      try {
        // In a real app, you would fetch this from the database
        // For now, return a placeholder
        return {
          hasCertificate: false,
          certificateUrl: null,
        };
      } catch (error) {
        console.error("Error fetching certificate:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Erro ao buscar certificado",
        });
      }
    }),
});
