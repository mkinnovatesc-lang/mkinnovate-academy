# MKinnovate Academy - TODO

## Melhorias de Design Premium (NOVA FASE)
- [x] Implementar navegação premium com menu claro
- [x] Redesenhar página inicial com hierarquia visual forte
- [x] Criar seção de depoimentos com fotos e resultados
- [x] Implementar checkout integrado sem redirecionamentos
- [x] Adicionar seções de benefícios, certificados e resultados
- [x] Adicionar badges de certificação
- [x] Melhorar CTAs com cores contrastantes
- [x] Criar seções bem compartimentadas para cada curso

## Autenticação e Banco de Dados
- [x] Configurar schema do banco de dados (usuários, cursos, compras, progresso, certificados)
- [x] Implementar autenticação com Manus OAuth
- [x] Criar migrations do banco de dados

## Páginas Públicas
- [x] Página inicial com depoimentos de alunos
- [x] Página de listagem de cursos
- [x] Página de detalhes de cada curso (IA, Web, Mobile, Edição)
- [ ] Página de checkout/compra

## Sistema de Pagamentos
- [x] Integrar Mercado Pago (credenciais configuradas e testadas)
- [x] Implementar endpoint de criação de preferência de pagamento
- [x] Configurar webhook para notificações de pagamento
- [x] Liberar acesso automaticamente após pagamento aprovado
- [x] Página de sucesso de pagamento
- [x] Página de falha de pagamento

## Área do Aluno
- [x] Página de área do aluno com cursos adquiridos
- [ ] Visualizar progresso dos cursos
- [ ] Acessar materiais e vídeos dos cursos
- [ ] Sistema de módulos e aulas

## Painel Administrativo
- [x] Dashboard com estatísticas gerais
- [x] Gráficos de vendas e receita
- [x] Lista de alunos cadastrados
- [x] Lista de vendas realizadas
- [ ] Gerenciamento de cursos (criar, editar, deletar)
- [ ] Gerenciamento de conteúdo (vídeos, materiais, módulos)

## Sistema de Certificados
- [ ] Gerar certificados em PDF automaticamente
- [ ] Armazenar certificados no S3
- [ ] Permitir download de certificados

## Notificações
- [x] Enviar notificação ao proprietário quando nova venda for concluída
- [x] Incluir detalhes do curso e informações do comprador

## Testes e Otimização
- [x] Testes unitários com Vitest
- [ ] Testes de integração
- [ ] Otimização de performance
- [ ] Testes de segurança
