import type { VercelRequest, VercelResponse } from '@vercel/node';
import { mercadopagoClient } from '../server/mercadopago';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  // Enable CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  try {
    const { courseId, courseTitle, price, userId } = req.body;

    if (!courseId || !courseTitle || !price) {
      res.status(400).json({ error: 'Missing required fields' });
      return;
    }

    const preference = {
      items: [
        {
          id: String(courseId),
          title: courseTitle,
          quantity: 1,
          unit_price: Number(price),
          currency_id: 'BRL',
        },
      ],
      payer: {
        email: 'customer@example.com',
      },
      back_urls: {
        success: `${req.headers['x-forwarded-proto'] || 'https'}://${req.headers['x-forwarded-host'] || req.headers.host}/payment-success`,
        failure: `${req.headers['x-forwarded-proto'] || 'https'}://${req.headers['x-forwarded-host'] || req.headers.host}/payment-failure`,
        pending: `${req.headers['x-forwarded-proto'] || 'https'}://${req.headers['x-forwarded-host'] || req.headers.host}/payment-pending`,
      },
      notification_url: `${req.headers['x-forwarded-proto'] || 'https'}://${req.headers['x-forwarded-host'] || req.headers.host}/api/webhook`,
      external_reference: `course_${courseId}_user_${userId}`,
    };

    const response = await mercadopagoClient.preferences.create(preference);

    res.status(200).json({
      init_point: response.init_point,
      url: response.init_point,
      id: response.id,
    });
  } catch (error) {
    console.error('Checkout error:', error);
    res.status(500).json({
      error: 'Failed to create payment preference',
      details: error instanceof Error ? error.message : 'Unknown error',
    });
  }
}
